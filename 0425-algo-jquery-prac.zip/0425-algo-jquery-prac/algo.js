var threeSumClosest = function(nums, target) {
    //sort nums
    nums.sort((a, b) => a - b)
    //sum
    let sum = 0;
    //diff
    let diff
    let n = nums.length - 1;
    //iterate over, i, L, R
    for (let i = 0, L = i + 1, R = n; i < n - 1; i++, L = i + 1, R = n){
        if(nums[i] === nums[i - 1]) continue;
        while(L < R){
            let tempSum = nums[i] + nums[L] + nums[R]
            let tempDiff = Math.abs(tempSum - target)
          
            if(tempDiff < diff || diff === undefined){diff = tempDiff
                                                     sum = tempSum}
            if(tempDiff === 0) break
            if( tempSum < target){
              L++
            }else{
              R--
            }
            }
    }
    //return sum
    return sum
};


// Example 1:


// Output: 2
// Explanation: The sum that is closest to the target is 2. (-1 + 2 + 1 = 2).