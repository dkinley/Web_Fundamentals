var myArr = [];
console.log(typeof myArr);
console.dir(myArr);
myArr.push(8);
console.log(myArr);
// => [8]